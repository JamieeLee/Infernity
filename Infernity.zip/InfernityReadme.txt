//By Qndel, 
//Discord link: https://discord.gg/rejUw5b
Detailed feature list:
A new difficulty called Inferno.
Special items with 3 affixes can drop there.

The third affix will only drop if the item has a suffix and a prefix. Additional affix doesn't follow the regular prefix/suffix rules, which mean that combinations that weren't possible before can occur.
Items can't get pairs of affixes that do the same thing (example: +%dmg and +%dmg/%hit).
Additional affix is never cursed.
Items with 3 affixes dropped on inferno are called "rares" while unique items that dropped on inferno are called "superuniques" and have 1 additional affix as well.
Durability enhancing affixes (Indestructible etc.) are going to be removed from the additional affix pool, as they are kind of useless (you can always increase the durability with a shrine).
+%armor affix is going to only appear on items that have base armor. +%dmg can still occur on any item because it works anyway.
The additional affix doesn't change item's price.

Compatibility with vanilla, but sadly in one direction = you can move your vanilla character to infernity, but if you move character from infernity to vanilla, items will morph like crazy (This is because inferno items have increased level to enable them to get the "dead" affixes (the ones you could only get from Wirt)
Running in town
Running in dungeon when out of combat - by out of combat it means being at least X tiles away from nearest monster that has targetted the player.

Highlighting enemies in combat

A config to enable or disable stuff

Fully shared xp - you don't need to poke or even be close! Seems in vanilla diablo the xp would be divided between the killers. In Infernity everyone gets 100% xp, so splitting to clear faster might be a good idea ;)

Black death doesn't permanently decrease health anymore! - it still decreases health, but not permanently, drinking a potion restores it back to normal.

Added xp bar - divided by 10 segments, each worth 10% xp

Minimap is shared between players

Gold pile max size increased to 60k (Can't be more because of variable type - at least for now)

Shop selection stays after buying item (it used to reset to first top item before)

Shift clicking potions in inventory adds them to belt

Remove/change permanent negative shrines (In general, things permanently damaging your character)

Show shrine effect in the description

Expand inventory (4tabs, switch by clicking on the icon or shift+1/2/3/4)

Make the map revealed by the shrine have a different color

Add monster resistances/immunities on the health bar
Red = fire immune, blue = lightning, yellow = magic.
Immune means it completely ignores that damage, while resistant means it takes 25%.
The frame around the health bar indicates monster type.
Lightblue = beast, orange = demon, white = undead.

Show other players on minimap

Items won't drop on death

Fix friendly fire - players won't damage each other if both have "player friendly" turned on.

Diablo is a unique monster and drops items - more on higher difficulties

Showing current/max on health/mana orbs

Alternate weapon slot + switching between weapons - Hotkey to switch is V. Can switch only while standing still.

Fixed duping

HD - right now the resolution is hardcoded in the exe, soon it will be possible to set it in the config.

Stash (You can only use it in town, you can quickswitch to it using Shift+5)
Click on stash tab name to rename it.

TrueColor support

Sprite limit raised to 10k - you can spam as many firewalls and chain lightnings as you want, they won't break anymore.

Toggle caps lock to emulate holding shift - only for attacking, doesn't emulate shift+1/2/3/4/5 clicks. You can press capslock once to make your character stand still and attack and press it again to return to normal behavior.
Hotkeys increased from 4 to 12, can now be saved. The hotkeys are F1-F12.

Loot filters - defined in lootFilter.lua. I've added a lot of example functions there, when you break the script, it might crash your game. If you still don't understand how to write a lootFilter, go to https://www.tutorialspoint.com/lua/

Barrels can be destroyed with spells/arrows. 
Clicking on the barrel will cause the standard behavior (character walks to the barrel and hits it in melee).
To destroy it from distance, click on it with shift (or caps lock turned on).

ddraw.dll - the default hotkey to see ddraw.dll menu is '~'. Not all keyboard have it, so I've added a second hotkey - scroll lock.
At the time of writing this readme, the resolution in the exe is 1280x960. Setting the ddraw.dll resolution width to be less than 1280 or height to be less than 960 will limit your mouse movement.

When pressing alt or putting the mouse over an object, trapped objects will be highlighted in red for rogue.


Spell power: A big gamechanger.
The code for it looks like this at the moment
int CalculateSpellPower(int pnum) {
    int power = 50;
    int activeSpellType = plr[pnum]._pRSplType;
    int magPower = (plr[pnum]._pMagic / 5);
    int spellLevel = plr[myplr]._pSplLvl[plr[pnum]._pRSpell] + plr[myplr]._pISplLvlAdd;

    power += 5 * spellLevel;

    power += magPower;
    int hpPercent = (plr[pnum]._pHPPer * 10) / 8;
    int reverseHpPercent = 100 - hpPercent;
    if (plr[pnum].pManaShield) {
        power = power * 3 / 4;
        power = (power*hpPercent*hpPercent)/10000;
    }
    if (!plr[pnum].pManaShield) {
        power += (power*reverseHpPercent) / 200;
    }

    if (activeSpellType == 2 || activeSpellType == 3) {
        power = power * 3 / 2;
    }
    return power;
}




Base spell power is 50%.
Then you gain 1% for every 5 magic (current magic, not base magic).
Then you get 5 for every spell level.

If you are using mana shield, you get a 25% penalty to your total power and then an additional penalty for missing hp (Power is equal to remaining hp squared. For example: If you have 50% hp, you will have 25% of your power, at 80 % hp you will have 64% of your power.)
This approach prevents the usage of infamous manashield bug (If your health was less or equal to the damage that you  have taken, there was no stun and equipment didn't get damaged). 
Right now you can still use that bug, but your spellpower will be ridiculously low, so it's not worth it.

To encourage a risky playstyle, there is a bonus up to 50% power for playing without manashield and having low health.
The total bonus is 0% at 100% hp and goes up to 50% at 0%.

You can zoom in/out using mouse scroll.
The resolution can't go below 640x480.



Changelog:
Development started: Aug 2, 2018
Aug 2, 2018 - 1.00 - Added Inferno difficulty and 3 affix items.
Aug 5, 2018 - 1.01 - Added health bar (can turn on/off in config)
Aug 6, 2018 - 1.02 - Added alt highlighting items
Aug 6, 2018 - 1.03 - Added running in town/dungeon and highlighting monsters in combat (something like infravision but you have to aggro monster to see it )(can turn on/off in config)
Aug 9, 2018 - 1.04 - Restored compatibility with vanilla, changed affix generation system (IMPORTANT! All items from previous versions will go crazy :( But the item system is good now). Compatibility is vanilla->infernity only. At least it means you can start playing infernity with your items from vanilla :)
Aug 9, 2018 - 1.05 - Added experience bar
Aug 10,2018 - 1.06 - Map shared between players, Uniques from Inferno will have an additional affix as well! They are called Superuniques
Aug 11,2018 - 1.07 - Gold pile max size increased from 5k to 1m, shift+clicking a scroll/potion in inventory will add it to belt, shop selection stays after buying, some fixes for spells
Aug 12,2018 - 1.08 - Shrines display their effect in description (goat shrines and cauldron't still don't), removed permanent mana decrease from shrines = we got rid of all stuff that could permanently damage the character! So it's safe to use goat shrines/cauldrons
Aug 12,2018 - 1.09 - The most important update so far, adds 4 tabs to inventory. You can switch by clicking or shift+1/2/3/4
Aug 14,2018 - 1.10 - fixed all bugs related to inventory/multiplayer - this will allow to expand the player structure in the future (can add more stuff)
Aug 17,2018 - 1.11 - motion interpolation for highlighted items, clicking highlighted name will walk to item/pick it up if nearby
Aug 21,2018 - 1.12 - added alternate weapon slot and switching between weapons using 'v' hotkey
Aug 23,2018 - 1.13 - fixes all issues with loading in single player, butcher should be in multiplayer too, portals shouldn't break in multiplayer
Aug 31,2018 - 1.14 - HD!
Sep 03,2018 - 1.15 - STASH!
Sep 05,2018 - 1.16 - True Color support (RGB)
Sep 07,2018 - 1.17 - Sprite limit raised to 10k! (Firewall/chainlightning/monster spells should always work)
Sep 08,2018 - 1.18 - Hotkeys F1-F12, they save in multiplayer
Sep 09,2018 - 1.19 - Loot Filters
Sep 13,2018 - 1.20 - Introducing Spell Power